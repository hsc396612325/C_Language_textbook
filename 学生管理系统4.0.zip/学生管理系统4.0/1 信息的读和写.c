#include "record.h"
//�ļ�ѧ����Ϣ¼��
struct student *Finput(char filename[]) 
{
	
	FILE *fp;
	struct student *pHead=NULL,*pEnd,*pNew;
	int sum=0,i,j,num;
	iCound[filename[5]-'0'-1]=0;
	pEnd=pHead=(struct student *)malloc(sizeof(struct student));
	fp=fopen(filename,"rt");
	if(fp==NULL)
	{
		printf("���ܴ��ļ�");
		exit(1); 
	}
	char a[20];//�ݴ���Ϣ 
	fscanf(fp,"%s",a);
	
	int temp[Classnum]={0};//�ݴ��Ŀ���� 
	while(!feof(fp))
	{
		sum=0;
		pNew=(struct student *)malloc(sizeof(struct student));
		strcpy(pNew->name,a);
		fscanf(fp,"%s %s",pNew->num,pNew->classes);
		
				
		struct score *spEnd,*spNew,*spt; //¼���Ŀ�ɼ� 
		pNew->ScorepHead=spEnd=(struct score *)malloc(sizeof(struct score));
		while(1)
		{
			spNew=(struct score *)malloc(sizeof(struct score));
			fscanf(fp,"%s",a);
			if(a[0]<'0'||a[0]>'9'||feof(fp))
				break;
			strcpy(spNew->date,a);
			spEnd->next=spNew;
			spEnd=spNew;	
		}
		spEnd->next=NULL;
		int k;
		for(k=0,spt=pNew->ScorepHead->next;spt!=NULL;spt=spt->next,k++)//�ַ���ת���� 
		{	
			for(j=0,num=0;spt->date[j];j++)
				num=num*10+spt->date[j]-'0';	
			sum=sum+num;
			temp[k]++;	
		} 
		pNew->aver=sum/k;	
			
		iCound[filename[5]-'0'-1]++;
		pEnd->next=pNew;
		pEnd=pNew;
	}
	for(i=0;i<Classnum;i++)
			subject[filename[5]-'0'-1][i]=temp[i]; 
	pEnd->next=NULL;
	fclose(fp);
	return pHead;
}
void combine()
{
	int i;
	struct student *pEnd,*pNew,*pt,t;
	iCound[5]=0;
	pEnd=StupHead[5]=(struct student *)malloc(sizeof(struct student));
	for(i=0;i<5;i++)
	{
		for(pt=StupHead[i]->next;pt!=NULL;pt=pt->next)
		{
			pNew=(struct student *)malloc(sizeof(struct student));
			*pNew=*pt;
			iCound[5]++; 
			pNew->next=NULL;
			pEnd->next=pNew;
			pEnd=pNew;
		} 
	}
}
void read()//��ȡ5�����ѧ����Ϣ+���ݷ��� 
{
	int i;
	char filename[5][20]={"class1.txt","class2.txt","class3.txt","class4.txt","class5.txt"};
	double a[Classnum]={0}; 
	for(i=0;i<5;i++)
	{
		StupHead[i]=Finput(filename[i]);
		Analysis(StupHead[i],i,i);
		iCound[5]=iCound[5]+iCound[i]; 
	}
	int j;
	for(i=0;i<5;i++)
		for(j=0;j<Classnum+1;j++)
			a[j]=a[j]+Aver[j][i]; 
	for(i=0;i<5;i++)
		Aver[5][i]=a[i]/5;
	combine();		
} 




//��Կ�����ȡ 
void Cip_input(char filename1[],char filename2[]) 
{
	FILE *fp_1,*fp_2;
	char key[30];
	cipLong=0;
	
		fp_1=fopen(filename1,"rt");
		fp_2=fopen(filename2,"rt");
	
	if(fp_1==NULL||fp_2==NULL)//�������ļ�����Կ�ļ�������ṹ������ 
	{
		printf("�ļ���ʧ�ܣ�\n");
		exit(0); 
	}
	int j,i;
	while(!feof(fp_1))
	{
		fscanf(fp_1,"%s %s\n",cip[cipLong].account,cip[cipLong].password);
		fscanf(fp_2,"%s\n",key);
		for(i=0;cip[cipLong].password[i];i++)
			cip[cipLong].password[i]=cip[cipLong].password[i]^key[i];
		cipLong++; 
	}
	
	fclose(fp_1);
	fclose(fp_2);

} 



//���ݵ�д�� 
void Input_1(struct student *pNew,int cla)//����ڵ��ֵ 
{
	int i,j,num,sum=0;
	char ch;
	fflush(stdin);
	printf("������������");
	gets(pNew->name);
	if(pNew->name[0]=='#')
		return; 
	iCound[cla]++;
	iCound[5]++;
	printf("������ѧ�ţ�");
	gets(pNew->num);
	printf("������༶��");
	gets(pNew->classes);
	
	printf("������ɼ�");
	struct score *spEnd,*spNew,*spt; 
	char a[10]; 
	int k=0;
	pNew->ScorepHead=spEnd=(struct score *)malloc(sizeof(struct score));
	while(1)
	{
		spNew=(struct score *)malloc(sizeof(struct score));
		scanf("%s",a);
		if(a[0]<'0'||a[0]>'9')
			break;
		subject[cla][k]++;
		strcpy(spNew->date,a);
		spEnd->next=spNew;
		spEnd=spNew;
		k++;	
	}
	spEnd->next=NULL;
	
	for(spt=pNew->ScorepHead->next;spt!=NULL;spt=spt->next)//�ַ���ת���� 
	{	
		for(j=0,num=0;spt->date[j];j++)
			num=num*10+spt->date[j]-'0';	
		sum=sum+num;	
	}	
		pNew->aver=sum*1.0/3;
	printf("\n");
}
struct student *Input(int cla)//�ֶ����� 
{
	struct student *pHead=NULL,*pEnd,*pNew;
	pEnd=pHead=(struct student *)malloc(sizeof(struct student));
	pNew=(struct student *)malloc(sizeof(struct student));
	printf("��������#ʱ��ֹͣ������Ϣ���������������ʱ�������һ����Ϣ\n");
	Input_1(pNew,cla);
	int i;
	for(i=0;i<Classnum;i++)
		subject[stuclass][i]=0;
	while(pNew->name[0]!='#')
	{
		pEnd->next=pNew;
		pNew->next=NULL;
		pEnd=pNew;
		pNew=(struct student *)malloc(sizeof(struct student)); 
		Input_1(pNew,cla);
	} 
	free(pNew);
	return pHead; 	
}
void Foutput(struct student *pHead,char filename[])//�ļ�¼�� 
{
	struct student *pt=pHead; 
	FILE *fp;
	int sum=0,i,j,num;
	pt=pt->next;
	fp=fopen(filename,"wt+");
	if(fp==NULL)
	{
		printf("���ܴ��ļ�");
		exit(1); 
	}
	while(pt)
	{
		struct score *spt;
		fprintf(fp,"\n%s %s %s ",pt->name,pt->num,pt->classes);
		for(spt=pt->ScorepHead->next;spt!=NULL;spt=spt->next)//�ַ���ת���� 
			fprintf(fp,"%s ",spt->date); 	
		pt=pt->next;
	}
	fclose(fp);
}
struct student *Write_Foutput(char filename[],int cla)//����������д���ļ��� 
{
	struct student *pHead;
	char ch;
	printf("һ�����������ݵĸ��£�����ԭ���ݶ��ᶪʧ\n");
	printf("ȷ�����и��°�Y\n"); 
	fflush(stdin);
	scanf("%c",&ch); 
	if(ch=='Y'||ch=='y')	
	{	
		pHead=Input(cla);
		Foutput(pHead,filename);
		printf("���³ɹ�\n");
		Sleep(150);
		exit(1); 
	}
	return pHead;
}



void Pass_Foutput(char filename1[],char filename2[])//����д���ĵ��� 
{
	FILE *fp_1,*fp_2;
	char acc[30]={0},pass[30],key[30],ch;
	int i,j;
		fp_1=fopen(filename1,"wt+");
		fp_2=fopen(filename2,"wt+");
	
	if(fp_1==NULL||fp_2==NULL)
	{
		printf("�ļ���ʧ�ܣ�\n");
		exit(0); 
	}
	srand((unsigned)time(NULL));
	int k;
	for(k=0;k<cipLong;k++)
	{
		strcpy(acc,cip[k].account); 
		strcpy(pass,cip[k].password);
		for(i=0;pass[i];i++)
		{
			key[i]=rand()%90+38;
			ch=key[i]^pass[i];
			if(isgraph(ch)==0)
				i--;
			else
				pass[i]=ch; 
		}
			key[i]=0;	
			fprintf(fp_1,"%s %s\n",acc,pass);
			fprintf(fp_2,"%s\n",key);
	}
	fclose(fp_1);
	fclose(fp_2);	 
}
