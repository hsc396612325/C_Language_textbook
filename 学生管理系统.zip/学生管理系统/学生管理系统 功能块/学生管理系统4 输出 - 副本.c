#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
struct student
{
	char name[20];//���� 
	char num[20];//ѧ�� 
	char classes[20];//�༶ 
	char score[3][10];//���� 
	double aver;//ƽ����
	struct student *next;//ָ���� 
}; 
int iCound; 
struct student *finput()//�ļ�¼�� 
{
	
	FILE *fp;
	struct student *pHead=NULL,*pEnd,*pNew;
	int sum=0,i,j,num;
	char filename[100]="123.txt"; 
	//printf("�������ļ�·�����ļ�����"); 
	//fflush(stdin); 
	//gets(filename);
	iCound=0;
	pEnd=pHead=(struct student *)malloc(sizeof(struct student));
	fp=fopen(filename,"rt+");
	if(fp==NULL)
	{
		printf("���ܴ��ļ�\n");
		exit(1); 
	}
	while(1)
	{
		sum=0;
		pNew=(struct student *)malloc(sizeof(struct student));
		fscanf(fp,"%s %s %s",pNew->name,pNew->num,pNew->classes);
		fscanf(fp,"%s %s %s",pNew->score[0],pNew->score[1],pNew->score[2]); 
		for(i=0;i<3;i++)//����ɼ��Ż� 
		{	
		 	num=0;
			for(j=0;pNew->score[i][j];j++)
				num=num*10+pNew->score[i][j]-'0';	
			sum=sum+num;	
		}	
		pNew->aver=sum*1.0/3;
		if(feof(fp))
			break;
		pEnd->next=pNew;
		pEnd=pNew;
		iCound++;
	}
	pEnd->next=NULL;
	fclose(fp);
	return pHead;
}
void output_t(struct student *pHead)//��� 
{
	int i=0;
	pHead=pHead->next;
	printf("������һ����%d��ѧ��\n",iCound);
	printf("���/����\t����\tѧ��\t�༶\t��Ŀһ\t��Ŀ��\t��Ŀ��\tƽ����\n");
	while(pHead!=NULL)
	{
		printf("No.%d\t\t",++i);
		printf("%s\t%s\t%s\t",pHead->name,pHead->num,pHead->classes);
		printf("%s\t%s\t%s\t",pHead->score[0],pHead->score[1],pHead->score[2]);
		printf("%.1lf\n",pHead->aver);
		pHead=pHead->next;
	}
}
void output_1(struct student *pHead)
{
	struct student *pt=pHead; 
	FILE *fp;
	int sum=0,i,j,num;
	iCound=0;
	pt=pt->next;
	fp=fopen("123.txt","rt+");
	if(fp==NULL)
	{
		printf("���ܴ��ļ�");
		exit(1); 
	}
	while(pt)
	{
		sum=0;
		fscanf(fp,"%s %s %s",pt->name,pt->num,pt->classes);
		fscanf(fp,"%s %s %s",pt->score[0],pt->score[1],pt->score[2]); 
		for(i=0;i<3;i++)//����ɼ��Ż� 
		{	
		 	num=0;
			for(j=0;pt->score[i][j];j++)
				num=num*10+pt->score[i][j]-'0';	
			sum=sum+num;	
		}	
		pt=pt->next;
	}
	fclose(fp);
	output_t(pHead);
}
void exchange(struct student *pj,struct student *pj_h,struct student *pj_1)
{
		struct student *pt;
		pt=pj->next;
		pj->next=pj_h->next;
		pj_h->next=pt;
				
		pt=pj_1->next;
		pj_1->next=pj_h->next;
		pj_h->next=pt;
}
void output_2(struct student *pHead,int a) //��ʽ2��� 
{
	int i,j,flag;
	struct student *pj_1,*pj,*pj_h;
	for(i=0;i<iCound-1;i++)
		for(j=0,pj=pHead,flag=0;j<iCound-i-1;j++) 
		{
			if(flag==0)
			{
				pj_1=pj;
				pj=pj->next;
				pj_h=pj->next;
			}
			if(flag==1)
			{
				pj_1=pj_1->next;
				pj_h=pj->next;
			}	
			flag=0;
			if(a==2&&(pj->aver)<(pj_h->aver))
			{
				exchange(pj,pj_h,pj_1);
				flag=1;	
			}
			else if(a==3&&strcmp(pj->num,pj_h->num)==1)	
			{
				printf("1 %s %s\n",pj->num,pj_h->num);
				exchange(pj,pj_h,pj_1);
				flag=1;	
			}
			else if(a==4&&strcmp(pj->classes,pj_h->classes)==1)
			{
				exchange(pj,pj_h,pj_1);
				flag=1;
			}
			else if(a==5&&strcmp(pj->name,pj_h->name)==1)
			{
				exchange(pj,pj_h,pj_1);
				flag=1;
			}
		}
	output_t(pHead);		
} 
int main(void)
{
	struct student *pHead;
	pHead=finput();//��Ϣ��¼�� 
	output_2(pHead,3); 
} 