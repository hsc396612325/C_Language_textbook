#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
struct student
{
	char name[20];//���� 
	char num[20];//ѧ�� 
	char classes[20];//�༶ 
	char score[3][10];//���� 
	double aver;//ƽ����
	struct student *next;//ָ���� 
}; 

int iCound; 
struct student *input()
{
	FILE *fp;
	struct student *pHead=NULL,*pEnd,*pNew;
	int sum=0,i,j,num;
	iCound=0;
	pEnd=pHead=(struct student *)malloc(sizeof(struct student));
	fp=fopen("123.txt","rt+");
	if(fp==NULL)
	{
		printf("���ܴ��ļ�");
		exit(1); 
	}
	while(1)
	{
		sum=0;
		pNew=(struct student *)malloc(sizeof(struct student));
		fscanf(fp,"%s %s %s",pNew->name,pNew->num,pNew->classes);
		fscanf(fp,"%s %s %s",pNew->score[0],pNew->score[1],pNew->score[2]); 
		for(i=0;i<3;i++)//����ɼ��Ż� 
		{	
		 	num=0;
			for(j=0;pNew->score[i][j];j++)
				num=num*10+pNew->score[i][j]-'0';	
			sum=sum+num;	
		}	
		pNew->aver=sum*1.0/3;
		if(feof(fp))
			break;
		pEnd->next=pNew;
		pEnd=pNew;
		iCound++;
	}
	pEnd->next=NULL;
	return pHead;
	fclose(fp);
}
void output(struct student *pHead)//��� 
{
	int i=0;
	pHead=pHead->next;
	printf("������һ����%d��ѧ��\n",iCound);
	printf("���/����\t����\tѧ��\t�༶\t��Ŀһ\t��Ŀ��\t��Ŀ��\tƽ����\n");
	while(pHead)
	{
		printf("No.%d\t\t",++i);
		printf("%s\t%s\t%s\t",pHead->name,pHead->num,pHead->classes);
		printf("%s\t%s\t%s\t",pHead->score[0],pHead->score[1],pHead->score[2]);
		printf("%.1lf\n",pHead->aver);
		pHead=pHead->next;
	}
}
int main(void)
{
	struct student *pHead;
	pHead=input();
	output(pHead);

} 