#include "record.h"
void Pass_Foutput()
{
	FILE *fp_1,*fp_2;
	char acc[30]={0},pass[30],key[30],clear[30],ch;
	int i;
	/*if(Fflag==1)*/
	fp_1=fopen(F_Cipher_S,"Wt+");
	fp_2=fopen(F_Cipher_M,"Wt+");
	
	if(fp_1==NULL)
	{
		printf("�ļ���ʧ�ܣ�\n");
		exit(0); 
	}
	if(fp_2==NULL)
	{
		printf("�ļ���ʧ�ܣ�\n");
		exit(0); 
	}
	srand((unsigned)time(NULL));
	while(acc[0]!='#')
	{
		printf("�������û�����");
		gets(acc); 
		printf("���������룺");
		gets(pass);
		for(i=0;pass[i];i++)
		{
			key[i]=rand()%26+97;
			ch=key[i]^pass[i];
			if(isgraph(ch)==0)
				i--;
			else
				pass[i]=ch; 
		}
		key[i]=0;	
		fprintf(fp_1,"%s %s\n",acc,pass);
		fprintf(fp_2,"%s\n",key);
	}
	fclose(fp_1);	 
}
