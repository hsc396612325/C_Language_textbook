#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
#include <conio.h>
#include <time.h> 
#define F_TEMP "temp.txt"//信息读入文件
#define F_Cipher_S "cipher_S"//学生帐号密码保存文件
#define F_Cipher_T "cipher_T" //老师密码保存文件
#define F_Cipher_A "cipher_A" //管理员密码保存文件 
#define F_Cipher_M "cipher_M"


struct cipher
{
	char account[30];
	char password[30];
}cip[50];
static int Long=0;
void Pass_Foutput()
{
	FILE *fp_1,*fp_2;
	char acc[30]={0},pass[30],key[30],clear[30],ch;
	int i;
	/*if(Fflag==1)*/
	fp_1=fopen(F_Cipher_S,"wt+");
	fp_2=fopen(F_Cipher_M,"wt+");
	
	if(fp_1==NULL)
	{
		printf("文件打开失败！\n");
		exit(0); 
	}
	if(fp_2==NULL)
	{
		printf("文件打开失败！\n");
		exit(0); 
	}
	srand((unsigned)time(NULL));
	fflush(stdin);
	printf("和书诚\n");
	while(acc[0]!='#')
	{
		fflush(stdin); 
		printf("请输入用户名：");
		fflush(stdin);
		gets(acc); 
		printf("请输入密码：");
		gets(pass);
		for(i=0;pass[i];i++)
		{
			key[i]=rand()%26+97;
			ch=key[i]^pass[i];
			if(isgraph(ch)==0)
				i--;
			else
				pass[i]=ch; 
		}
		key[i]=0;	
		fprintf(fp_1,"%s %s\n",acc,pass);
		fprintf(fp_2,"%s\n",key);
	}
	fclose(fp_1);
	fclose(fp_2);	 
}
void Landing()//登录 
{
	int order=Long,i,j;
	char acc[30],pass[30],key[30];
	FILE *fp_1,*fp_2;
	fp_1=fopen(F_Cipher_S,"rt+");
	fp_2=fopen(F_Cipher_M,"rt+");
	if(fp_1==NULL)
	{
		printf("文件打开失败！\n");
		exit(0); 
	}
	if(fp_2==NULL)
	{
		printf("文件打开失败！\n");
		exit(0); 
	}
	while(!feof(fp_1))
	{
		fscanf(fp_1,"%s %s\n",cip[i].account,cip[i].password);
		fscanf(fp_2,"%s\n",key);
		for(j=0;cip[i].password[j];j++)
			cip[i].password[j]=cip[i].password[j]^key[i];
		printf("%s %s\n",cip[i].account,cip[i].password);
		
	}
	fclose(fp_1);
	fclose(fp_2);
	/*printf("请输入帐号：");
	gets(acc);
	while(order==Long) 
	{
	for(order=0;order<Long&&strcmp(acc,cip[i].account)!=0;order++)
		;
	if(i==Long)
		printf("用户不存在！请重新输入\n");  	
	}
	 
	for(i=0;i<3;i++)
	{
		printf("请输入密码：");	
		for(j=0;acc[j-1]!=13;j++)
		{
			pass[j]=getch();
			if(pass[j]==8&&j>0)
				printf("\b \b",j-=2;);		
			else if(j>=0)
				printf("*");
			else
				printf(" ");
		}
		printf("\n");
		acc[j-1]='\0';	
		if(strcmp(cip[Long].password,acc)==0)
	 		return;
	}*/ 
}
int main(void)
{
	Pass_Foutput();
	Landing();
}