#include "record.h"
struct cipher
{
	char account[30];
	char password[30];
}cip[50];
static int Long=0; 
void Lan_Finput()
{
	FILE *fp;
	fp=fopen(F_Cipher_S,"r");
	if(fp==NULL)
	{
		printf("�ļ���ʧ�ܣ�\n");
		exit;
	}
	while(!feof(fp))
	{
		fscanf(fp,"%s %s\n",cip[Long].account,cip[Long].password);
		Long++;
	}
	fclose(fp);
}
void Landing()//��¼ 
{
	int order=Long,j;
	char acc[30],pass[30];
	printf("�������ʺţ�");
	gets(acc);
	while(order==Long) 
	{
	for(order=0;order<Long&&strcmp(acc,cip[i].account)!=0;order++)
		;
	if(i==Long)
		printf("�û������ڣ�����������\n");  	
	}
	 
	for(i=0;i<3;i++)
	{
		printf("���������룺");	
		for(j=0;acc[j-1]!=13;j++)
		{
			pass[j]=getch();
			if(pass[j]==8&&j>0)
				printf("\b \b",j-=2;);		
			else if(j>=0)
				printf("*");
			else
				printf(" ");
		}
		printf("\n");
		acc[j-1]='\0';	
		if(strcmp(cip[Long].password,acc)==0)
	 		return;
	}
}
