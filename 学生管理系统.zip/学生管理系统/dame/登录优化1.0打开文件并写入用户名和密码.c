#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#define NAME "cipher.txt"
int main(void)
{
	FILE *fp;
	char filename[30]=NAME;
	char ID[20],password[20]; 
	fp=fopen(filename,"wt+");
	if(fp==NULL)
	{
		printf("�ļ���ʧ��\n");
		exit(0);
	}
	while(ID[0]!='#')
	{
		gets(ID);
		gets(password);
		fprintf(fp,"%s %s\n",ID,password);
	}
	fclose(fp);
} 